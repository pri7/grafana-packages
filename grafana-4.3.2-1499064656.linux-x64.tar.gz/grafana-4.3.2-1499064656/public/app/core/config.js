/*! grafana - v4.3.2-1499064656 - 2017-07-03
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["app/core/settings"],function(a){"use strict";var b=window.grafanaBootData||{settings:{}},c=b.settings;return c.bootData=b,new a(c)});