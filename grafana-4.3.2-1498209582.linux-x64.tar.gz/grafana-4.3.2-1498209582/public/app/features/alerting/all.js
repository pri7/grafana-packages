/*! grafana - v4.3.2-1498209582 - 2017-06-23
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./alert_list_ctrl","./notifications_list_ctrl","./notification_edit_ctrl"],function(a,b){"use strict";b&&b.id;return{setters:[function(a){},function(a){},function(a){}],execute:function(){}}});