/*! grafana - v4.3.2-1498209582 - 2017-06-23
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["lodash"],function(a){"use strict";return function(b){var c={datasources:{},window_title_prefix:"Grafana - ",panels:{},new_panel_title:"Panel Title",playlist_timespan:"1m",unsaved_changes_warning:!0,appSubUrl:""};return a.extend({},c,b)}});