/*! grafana - v4.3.2-1498209582 - 2017-06-23
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a,b){"use strict";function c(a,b,c,d){for(var e in c)c.hasOwnProperty(e)&&(a[e]=void 0===b[e]?c[e]:b[e])}b&&b.id;return a("assignModelProperties",c),{setters:[],execute:function(){}}});