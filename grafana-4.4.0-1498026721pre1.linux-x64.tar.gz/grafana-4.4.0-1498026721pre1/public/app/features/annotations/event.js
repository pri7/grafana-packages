/*! grafana - v4.4.0-1498026721pre1 - 2017-06-21
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a,b){"use strict";var c;b&&b.id;return{setters:[],execute:function(){c=function(){function a(){}return a}(),a("AnnotationEvent",c)}}});