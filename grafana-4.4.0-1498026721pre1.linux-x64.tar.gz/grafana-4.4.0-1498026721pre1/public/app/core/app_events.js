/*! grafana - v4.4.0-1498026721pre1 - 2017-06-21
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./utils/emitter"],function(a,b){"use strict";var c,d;b&&b.id;return{setters:[function(a){c=a}],execute:function(){d=new c.Emitter,a("default",d)}}});