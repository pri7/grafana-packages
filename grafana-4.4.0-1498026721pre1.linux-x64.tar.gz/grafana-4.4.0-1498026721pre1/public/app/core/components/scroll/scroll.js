/*! grafana - v4.4.0-1498026721pre1 - 2017-06-21
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

